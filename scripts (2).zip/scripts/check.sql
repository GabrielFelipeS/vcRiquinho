\l
\c vcriquinho
\d conta
\d produto
\d produto_conta
\d pessoa

\c dbTest_vcRiquinho
\d conta
\d produto
\d produto_conta
\d pessoa

